
export function Button({ className = "", children }: any) {
  return <button className={className}>{children}</button>;
}
